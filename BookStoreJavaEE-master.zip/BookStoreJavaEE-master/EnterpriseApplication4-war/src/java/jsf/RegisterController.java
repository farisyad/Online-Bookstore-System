package jsf;

import entities.Users;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import sessions.UsersFacade;

@Named("registerController")
@RequestScoped
public class RegisterController implements Serializable {
    
    @EJB
    private UsersFacade usersFacade;
    
    @PersistenceContext(unitName = "EnterpriseApplication4-warPU")
    private EntityManager em;
    
    private String username;
    private String password;
    private String confirmPassword;
    private String email;
    
    public RegisterController() {
    }
    
    public String register() {
        // Validate input
        if (!password.equals(confirmPassword)) {
            FacesContext.getCurrentInstance().addMessage(
                null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Passwords do not match", null));
            return null;
        }
        
        // Check if username already exists
        try {
            Users existingUser = (Users) em.createQuery("SELECT u FROM Users u WHERE u.username = :username")
                .setParameter("username", username)
                .getSingleResult();
            
            FacesContext.getCurrentInstance().addMessage(
                null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Username already exists", null));
            return null;
        } catch (javax.persistence.NoResultException e) {
            // Username is unique, proceed with registration
            Users newUser = new Users();
            newUser.setUsername(username);
            newUser.setPassword(password);
            newUser.setEmail(email);
            newUser.setRole("user"); // Default role for new users
            
            try {
                usersFacade.create(newUser);
                
                // Redirect to login page after successful registration
                FacesContext.getCurrentInstance().addMessage(
                    null, 
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Registration successful", null));
                
                return "/login?faces-redirect=true";
            } catch (Exception ex) {
                FacesContext.getCurrentInstance().addMessage(
                    null, 
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Registration failed", null));
                return null;
            }
        }
    }
    
    // Getters and Setters
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getConfirmPassword() {
        return confirmPassword;
    }
    
    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
}
